const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || process.env.AURADESK_CLOUD_PORT || 8787);
const DATA_DIR = process.env.AURADESK_CLOUD_DATA_DIR || path.join(__dirname, 'cloud-data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');
const DEFAULT_TOKEN = process.env.AURADESK_CLOUD_TOKEN || 'auradesk-demo-token';

let store = {
  devices: {},
  reminders: [],
  capturedNotifications: [],
  events: []
};

const clients = new Set();

function loadStore() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      store = { ...store, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) };
    }
  } catch (error) {
    console.warn('读取云端数据失败：', error.message);
  }
}

function saveStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2));
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-auradesk-token, x-auradesk-device-id',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise(resolve => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) req.destroy();
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { resolve({}); }
    });
  });
}

function getToken(req, urlObj) {
  const auth = req.headers.authorization || '';
  if (auth.toLowerCase().startsWith('bearer ')) return auth.slice(7).trim();
  return req.headers['x-auradesk-token'] || urlObj.searchParams.get('token') || '';
}

function isAuthorized(req, urlObj) {
  return String(getToken(req, urlObj)) === String(DEFAULT_TOKEN);
}

function normalizeReminder(input = {}) {
  const now = new Date().toISOString();
  return {
    id: input.id || crypto.randomUUID(),
    title: String(input.title || '新的提醒').trim().slice(0, 80) || '新的提醒',
    time: String(input.time || '').trim().slice(0, 40),
    type: String(input.type || '普通').trim().slice(0, 20),
    note: String(input.note || '').trim().slice(0, 500),
    done: Boolean(input.done),
    source: String(input.source || 'cloud').trim().slice(0, 40),
    createdAt: input.createdAt || now,
    updatedAt: now
  };
}

function recordEvent(type, payload = {}) {
  const event = {
    id: crypto.randomUUID(),
    type,
    payload,
    createdAt: new Date().toISOString()
  };
  store.events.unshift(event);
  store.events = store.events.slice(0, 500);
  saveStore();
  broadcast(event);
  return event;
}

function broadcast(event) {
  const message = `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`;
  for (const res of [...clients]) {
    try { res.write(message); }
    catch { clients.delete(res); }
  }
}

function startSse(req, res) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-store, no-transform',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*'
  });
  res.write(': AuraDesk cloud events connected\n\n');
  clients.add(res);
  req.on('close', () => clients.delete(res));
}

async function handleRequest(req, res) {
  const host = req.headers.host || `127.0.0.1:${PORT}`;
  const urlObj = new URL(req.url, `http://${host}`);
  const pathname = decodeURIComponent(urlObj.pathname);

  if (req.method === 'OPTIONS') return sendJson(res, 200, { ok: true });
  if (pathname === '/health') return sendJson(res, 200, { ok: true, app: 'AuraDesk Cloud', port: PORT });

  if (!pathname.startsWith('/api/')) return sendJson(res, 404, { ok: false, message: 'Not found' });
  if (!isAuthorized(req, urlObj)) return sendJson(res, 401, { ok: false, message: '云端 token 不正确' });

  if (req.method === 'GET' && pathname === '/api/events') return startSse(req, res);

  if (req.method === 'POST' && pathname === '/api/devices/register') {
    const body = await readBody(req);
    const deviceId = String(body.deviceId || req.headers['x-auradesk-device-id'] || crypto.randomUUID()).slice(0, 80);
    store.devices[deviceId] = {
      deviceId,
      name: String(body.name || 'AuraDesk 设备').slice(0, 80),
      platform: String(body.platform || 'unknown').slice(0, 40),
      lastSeenAt: new Date().toISOString()
    };
    saveStore();
    const event = recordEvent('device.registered', store.devices[deviceId]);
    return sendJson(res, 200, { ok: true, device: store.devices[deviceId], event });
  }

  if (req.method === 'GET' && pathname === '/api/reminders') {
    return sendJson(res, 200, { ok: true, reminders: store.reminders });
  }

  if (req.method === 'POST' && pathname === '/api/reminders') {
    const body = await readBody(req);
    const reminder = normalizeReminder(body);
    const existingIndex = store.reminders.findIndex(item => item.id === reminder.id);
    if (existingIndex >= 0) store.reminders[existingIndex] = reminder;
    else store.reminders.unshift(reminder);
    saveStore();
    const event = recordEvent(existingIndex >= 0 ? 'reminder.updated' : 'reminder.created', reminder);
    return sendJson(res, existingIndex >= 0 ? 200 : 201, { ok: true, reminder, event });
  }

  const reminderMatch = pathname.match(/^\/api\/reminders\/([^/]+)$/);
  if (reminderMatch) {
    const id = reminderMatch[1];
    const index = store.reminders.findIndex(item => item.id === id);
    if (index < 0) return sendJson(res, 404, { ok: false, message: '提醒不存在' });

    if (req.method === 'PATCH' || req.method === 'PUT') {
      const body = await readBody(req);
      store.reminders[index] = normalizeReminder({ ...store.reminders[index], ...body, id });
      saveStore();
      const event = recordEvent('reminder.updated', store.reminders[index]);
      return sendJson(res, 200, { ok: true, reminder: store.reminders[index], event });
    }

    if (req.method === 'DELETE') {
      const [removed] = store.reminders.splice(index, 1);
      saveStore();
      const event = recordEvent('reminder.deleted', removed);
      return sendJson(res, 200, { ok: true, removed, event });
    }
  }

  if (req.method === 'POST' && pathname === '/api/notifications/capture') {
    const body = await readBody(req);
    const item = {
      id: crypto.randomUUID(),
      deviceId: String(body.deviceId || req.headers['x-auradesk-device-id'] || 'unknown').slice(0, 80),
      appName: String(body.appName || '').slice(0, 80),
      packageName: String(body.packageName || '').slice(0, 120),
      title: String(body.title || '').slice(0, 120),
      text: String(body.text || '').slice(0, 500),
      postTime: body.postTime || Date.now(),
      createdAt: new Date().toISOString()
    };
    store.capturedNotifications.unshift(item);
    store.capturedNotifications = store.capturedNotifications.slice(0, 1000);
    saveStore();
    const event = recordEvent('notification.captured', item);
    return sendJson(res, 201, { ok: true, notification: item, event });
  }

  if (req.method === 'POST' && pathname === '/api/events') {
    const body = await readBody(req);
    const event = recordEvent(String(body.type || 'custom.event').slice(0, 80), body.payload || {});
    return sendJson(res, 201, { ok: true, event });
  }

  return sendJson(res, 404, { ok: false, message: '接口不存在' });
}

loadStore();
http.createServer((req, res) => {
  handleRequest(req, res).catch(error => {
    console.error('AuraDesk Cloud error:', error);
    sendJson(res, 500, { ok: false, message: error.message });
  });
}).listen(PORT, '0.0.0.0', () => {
  console.log(`AuraDesk Cloud 已启动：http://127.0.0.1:${PORT}`);
  console.log(`当前演示 token：${DEFAULT_TOKEN}`);
});
