const { app, BrowserWindow, screen, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const os = require('os');
const crypto = require('crypto');
const QRCode = require('qrcode');

const API_PORT = Number(process.env.AURADESK_PORT || 37821);
const PAIR_CODE = String(Math.floor(100000 + Math.random() * 900000));

// 云端模式配置：部署 cloud-server.js 后，把公网地址和 token 填到环境变量即可。
// 示例：AURADESK_CLOUD_URL=https://your-domain.com AURADESK_CLOUD_TOKEN=*** npm start
const CLOUD_URL = String(process.env.AURADESK_CLOUD_URL || '').replace(/\/$/, '');
const CLOUD_TOKEN = String(process.env.AURADESK_CLOUD_TOKEN || '');
const CLOUD_DEVICE_ID = String(process.env.AURADESK_DEVICE_ID || `desktop-${os.hostname()}`).slice(0, 80);

let mainWindow = null;
let apiServer = null;
let dragTimer = null;
let dragOffset = { x: 0, y: 0 };
let reminders = [];
let dataFile = null;
let cloudEventBuffer = '';

function getDataFile() {
  if (!dataFile) {
    dataFile = path.join(app.getPath('userData'), 'reminders.json');
  }
  return dataFile;
}

function loadReminders() {
  try {
    const file = getDataFile();
    if (fs.existsSync(file)) {
      reminders = JSON.parse(fs.readFileSync(file, 'utf8')) || [];
    }
  } catch (error) {
    console.warn('读取提醒数据失败：', error.message);
    reminders = [];
  }
}

function saveReminders() {
  try {
    const file = getDataFile();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(reminders, null, 2));
  } catch (error) {
    console.warn('保存提醒数据失败：', error.message);
  }
}

function getLanIp() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

function getConnectionInfo() {
  const ip = getLanIp();
  const mobileUrl = `http://${ip}:${API_PORT}/mobile?code=${PAIR_CODE}`;
  return {
    ip,
    port: API_PORT,
    pairCode: PAIR_CODE,
    mobileUrl,
    qrUrl: `http://${ip}:${API_PORT}/qr.svg?text=${encodeURIComponent(mobileUrl)}`,
    cloudEnabled: Boolean(CLOUD_URL && CLOUD_TOKEN),
    cloudUrl: CLOUD_URL || '',
    cloudDeviceId: CLOUD_DEVICE_ID
  };
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-auradesk-code',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function sendText(res, status, body, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': contentType,
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) req.destroy();
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        resolve({});
      }
    });
  });
}

function cloudRequest(method, endpoint, payload) {
  if (!CLOUD_URL || !CLOUD_TOKEN) return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const target = new URL(endpoint, CLOUD_URL);
      const body = payload ? JSON.stringify(payload) : '';
      const transport = target.protocol === 'https:' ? require('https') : require('http');
      const req = transport.request(target, {
        method,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Authorization': `Bearer ${CLOUD_TOKEN}`,
          'x-auradesk-device-id': CLOUD_DEVICE_ID,
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: 5000
      }, (res) => {
        res.resume();
        res.on('end', () => resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode }));
      });
      req.on('error', (error) => {
        console.warn('云端同步失败：', error.message);
        resolve({ ok: false, error: error.message });
      });
      req.on('timeout', () => {
        req.destroy(new Error('cloud request timeout'));
      });
      if (body) req.write(body);
      req.end();
    } catch (error) {
      console.warn('云端请求配置错误：', error.message);
      resolve({ ok: false, error: error.message });
    }
  });
}

function syncReminderToCloud(reminder, action = 'created') {
  if (!CLOUD_URL || !CLOUD_TOKEN) return;
  const payload = { ...reminder, source: `desktop:${action}`, deviceId: CLOUD_DEVICE_ID };
  cloudRequest('POST', '/api/reminders', payload);
}

function registerCloudDevice() {
  if (!CLOUD_URL || !CLOUD_TOKEN) return;
  cloudRequest('POST', '/api/devices/register', {
    deviceId: CLOUD_DEVICE_ID,
    name: `AuraDesk Desktop ${os.hostname()}`,
    platform: process.platform
  });
}

function handleCloudEvent(event) {
  if (!event || !event.type) return;
  if (event.type === 'pet.speak' && event.payload) {
    callAvatar(String(event.payload.text || '手机端通过云端呼叫我啦。').slice(0, 180), String(event.payload.state || 'happy').slice(0, 20));
    return;
  }
  if (event.type === 'notification.captured' && event.payload) {
    const title = event.payload.title || event.payload.appName || '手机通知';
    callAvatar(`手机捕获到提醒：${title}`, 'alert');
  }
}

function connectCloudEvents() {
  if (!CLOUD_URL || !CLOUD_TOKEN) return;
  try {
    const target = new URL('/api/events', CLOUD_URL);
    const transport = target.protocol === 'https:' ? require('https') : require('http');
    const req = transport.request(target, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${CLOUD_TOKEN}`,
        'x-auradesk-device-id': CLOUD_DEVICE_ID
      },
      timeout: 0
    }, (res) => {
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        cloudEventBuffer += chunk;
        const parts = cloudEventBuffer.split('\n\n');
        cloudEventBuffer = parts.pop() || '';
        for (const part of parts) {
          const line = part.split('\n').find(item => item.startsWith('data: '));
          if (!line) continue;
          try { handleCloudEvent(JSON.parse(line.slice(6))); } catch {}
        }
      });
      res.on('end', () => setTimeout(connectCloudEvents, 3000));
    });
    req.on('error', () => setTimeout(connectCloudEvents, 5000));
    req.end();
  } catch (error) {
    console.warn('云端事件连接失败：', error.message);
  }
}

function checkPairCode(req, urlObj) {
  const code = req.headers['x-auradesk-code'] || urlObj.searchParams.get('code') || '';
  return String(code) === PAIR_CODE;
}

function normalizeReminder(input = {}) {
  return {
    id: input.id || crypto.randomUUID(),
    title: String(input.title || '新的提醒').trim().slice(0, 80) || '新的提醒',
    time: String(input.time || '').trim().slice(0, 40),
    type: String(input.type || '普通').trim().slice(0, 20),
    note: String(input.note || '').trim().slice(0, 200),
    done: Boolean(input.done),
    createdAt: input.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

function notifyRenderer(event, payload = {}) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.webContents.send(event, payload);
}

function callAvatar(text, state = 'alert') {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const safeText = JSON.stringify(text);
  const safeState = JSON.stringify(state);
  mainWindow.webContents.executeJavaScript(`
    if (window.AuraDeskAvatar && window.AuraDeskAvatar.speakAndShow) {
      window.AuraDeskAvatar.openInterface && window.AuraDeskAvatar.openInterface();
      window.AuraDeskAvatar.speakAndShow(${safeText}, { state: ${safeState} });
    }
  `).catch(() => {});
}

async function handleQr(req, res, urlObj) {
  const target = urlObj.searchParams.get('text') || getConnectionInfo().mobileUrl;
  try {
    const svg = await QRCode.toString(target, {
      type: 'svg',
      width: 280,
      margin: 2,
      color: {
        dark: '#7c5872',
        light: '#fff8fc'
      }
    });
    sendText(res, 200, svg, 'image/svg+xml; charset=utf-8');
  } catch (error) {
    sendText(res, 500, '二维码生成失败：' + error.message);
  }
}

function serveStatic(res, filePath, contentType) {
  fs.readFile(filePath, 'utf8', (err, content) => {
    if (err) return sendText(res, 404, 'Not found');
    sendText(res, 200, content, contentType);
  });
}

async function handleApi(req, res) {
  const host = req.headers.host || `127.0.0.1:${API_PORT}`;
  const urlObj = new URL(req.url, `http://${host}`);
  const pathname = decodeURIComponent(urlObj.pathname);

  if (req.method === 'OPTIONS') return sendJson(res, 200, { ok: true });
  if (pathname === '/' || pathname === '/mobile') {
    return serveStatic(res, path.join(__dirname, 'mobile.html'), 'text/html; charset=utf-8');
  }
  if (pathname === '/qr.svg') return await handleQr(req, res, urlObj);

  if (!pathname.startsWith('/api/')) return sendText(res, 404, 'Not found');
  if (!checkPairCode(req, urlObj) && pathname !== '/api/status') {
    return sendJson(res, 401, { ok: false, message: '配对码不正确，请从桌面端重新扫码连接。' });
  }

  if (req.method === 'GET' && pathname === '/api/status') {
    return sendJson(res, 200, { ok: true, app: 'AuraDesk', ...getConnectionInfo(), reminderCount: reminders.length });
  }

  if (req.method === 'GET' && pathname === '/api/reminders') {
    return sendJson(res, 200, { ok: true, reminders });
  }

  if (req.method === 'POST' && pathname === '/api/reminders') {
    const body = await readBody(req);
    const reminder = normalizeReminder(body);
    reminders.unshift(reminder);
    saveReminders();
    syncReminderToCloud(reminder, 'created');
    notifyRenderer('reminders-updated', { reminders });
    callAvatar(`手机端新增提醒：${reminder.title}`, 'happy');
    return sendJson(res, 201, { ok: true, reminder, reminders });
  }

  const match = pathname.match(/^\/api\/reminders\/([^/]+)$/);
  if (match) {
    const id = match[1];
    const index = reminders.findIndex(item => item.id === id);
    if (index < 0) return sendJson(res, 404, { ok: false, message: '提醒不存在' });

    if (req.method === 'PATCH' || req.method === 'PUT') {
      const body = await readBody(req);
      reminders[index] = normalizeReminder({ ...reminders[index], ...body, id });
      saveReminders();
      syncReminderToCloud(reminders[index], 'updated');
      notifyRenderer('reminders-updated', { reminders });
      return sendJson(res, 200, { ok: true, reminder: reminders[index], reminders });
    }

    if (req.method === 'DELETE') {
      const [removed] = reminders.splice(index, 1);
      saveReminders();
      notifyRenderer('reminders-updated', { reminders });
      return sendJson(res, 200, { ok: true, removed, reminders });
    }
  }

  if (req.method === 'POST' && pathname === '/api/desktop/speak') {
    const body = await readBody(req);
    const text = String(body.text || '手机端已连接 AuraDesk。').slice(0, 180);
    const state = String(body.state || 'happy').slice(0, 20);
    callAvatar(text, state);
    return sendJson(res, 200, { ok: true });
  }

  return sendJson(res, 404, { ok: false, message: '接口不存在' });
}

function startApiServer() {
  loadReminders();
  apiServer = http.createServer((req, res) => {
    handleApi(req, res).catch(error => {
      console.error('API 处理失败：', error);
      sendJson(res, 500, { ok: false, message: error.message });
    });
  });

  apiServer.listen(API_PORT, '0.0.0.0', () => {
    console.log('AuraDesk 手机端本地 API 已启动：', getConnectionInfo().mobileUrl);
  });

  apiServer.on('error', (error) => {
    console.error('AuraDesk 本地 API 启动失败：', error.message);
  });
}

function createWindow() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  const windowWidth = 390;
  const windowHeight = Math.min(700, Math.max(560, height - 40));

  mainWindow = new BrowserWindow({
    width: windowWidth,
    height: windowHeight,
    x: Math.max(20, width - windowWidth - 20),
    y: Math.max(20, height - windowHeight - 20),
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    hasShadow: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

function stopAvatarDrag() {
  if (dragTimer) {
    clearInterval(dragTimer);
    dragTimer = null;
  }
}

ipcMain.on('avatar-drag-start', () => {
  if (!mainWindow) return;
  stopAvatarDrag();

  const cursor = screen.getCursorScreenPoint();
  const bounds = mainWindow.getBounds();
  dragOffset = {
    x: cursor.x - bounds.x,
    y: cursor.y - bounds.y
  };

  dragTimer = setInterval(() => {
    if (!mainWindow || mainWindow.isDestroyed()) {
      stopAvatarDrag();
      return;
    }
    const point = screen.getCursorScreenPoint();
    mainWindow.setPosition(
      Math.round(point.x - dragOffset.x),
      Math.round(point.y - dragOffset.y),
      false
    );
  }, 16);
});

ipcMain.on('avatar-drag-stop', stopAvatarDrag);

// 点击穿透控制
ipcMain.on('set-ignore-mouse', (_event, ignore) => {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.setIgnoreMouseEvents(ignore, { forward: true });
});

ipcMain.handle('get-mobile-connection', () => getConnectionInfo());
ipcMain.handle('get-reminders', () => reminders);
ipcMain.handle('save-reminder', (_event, input) => {
  const reminder = normalizeReminder(input);
  reminders.unshift(reminder);
  saveReminders();
  syncReminderToCloud(reminder, 'created');
  notifyRenderer('reminders-updated', { reminders });
  return reminders;
});
ipcMain.handle('update-reminder', (_event, id, patch) => {
  const index = reminders.findIndex(item => item.id === id);
  if (index >= 0) {
    reminders[index] = normalizeReminder({ ...reminders[index], ...patch, id });
    saveReminders();
    syncReminderToCloud(reminders[index], 'updated');
  }
  notifyRenderer('reminders-updated', { reminders });
  return reminders;
});
ipcMain.handle('delete-reminder', (_event, id) => {
  reminders = reminders.filter(item => item.id !== id);
  saveReminders();
  notifyRenderer('reminders-updated', { reminders });
  return reminders;
});

app.whenReady().then(() => {
  registerCloudDevice();
  connectCloudEvents();
  startApiServer();
  createWindow();
});

app.on('window-all-closed', () => {
  stopAvatarDrag();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  stopAvatarDrag();
  if (apiServer) apiServer.close();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
